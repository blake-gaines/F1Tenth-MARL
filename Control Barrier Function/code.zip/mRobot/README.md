Project: mRobot

This project aims to develop a provably-correct trajectory generation and controller for a robot carrying elevated heavy loads on slopes with non-constant frictional forces and dynamic obstacles. 