function Traj_des = Cubic_Spline_Curve(points, t, V_init, V_final, dt, Tf)

% default value assignment
    switch nargin
        case 0
            points = [-250 -50; -215 -5; -175 40; -115 20; -70 -20; -10 -10];
            t = [0 6 12 18 24 30];
            V_init = 0;
            V_final = 0;
            dt=0.01;
            Tf = 30;
        case 1
            t = [0 6 12 18 24 30];
            V_init = 0;
            V_final = 0;
            dt=0.01;
            Tf = 30;
        case 2
            V_init = 0;
            V_final = 0;
            dt=0.01;
            Tf = 30;
        case 3
            V_final = 0;
            dt=0.01;
            Tf = 30;
        case 4
            dt=0.01;
            Tf = 30;
        case 5
            Tf = 30;
        case 6
        otherwise
            error('5 input only (points, V_init, V_final, dt, Tf');
    end

    % X and Y coordinates of waypoints
    x = points(:,1);
    y = points(:,2);

    % time steps and initial and final slope of trajectory curves
    tq = 0:dt:Tf;
    slope0x = V_init;
    slopeFx = V_final;
    slope0y = 0;
    slopeFy = 0;

    % X-coordinate trajectory w.r.t. time
    % Polynomial of Trajectory in X-direction
    xpol = spline(t,[slope0x; x; slopeFx]);
    xq =ppval(xpol,tq);

    % Polynomial of Velocity in X-direction
    xdpol = fnder(xpol,1);
    xdq = ppval(xdpol,tq);

    % Polynomial of Acceleration in X-Direction
    xddpol = fnder(xpol,2);
    xddq = ppval(xddpol,tq);

    % Y-coordinate trajectory w.r.t. time
    % Polynomial of Trajectory in Y-direction
    ypol = spline(t,[slope0y; y; slopeFy]);
    yq = ppval(ypol,tq);

    % Polynomial of Velocity in Y-direction
    ydpol = fnder(ypol,1);
    ydq = ppval(ydpol,tq);

    % Polynomial of Acceleration in Y-Direction
    yddpol = fnder(ypol,2);
    yddq = ppval(yddpol,tq);

    % Curvature of car at each point to calculate corresponding Yaw Rate
    K = (xdq.*yddq - xddq.*ydq)./(xdq.^2 + ydq.^2).^1.5;

    % Calculation of Yaw Rate using corresponding Curvature
    wref = K.*xdq;
    wref(1) = 0;

    % Calculating reference velocity at each point of trajectory
    thetaref = atan2(ydq, xdq);
    vref = xdq.*cos(thetaref) + ydq.*sin(thetaref);

    % Desired Trajectory
    Traj_des = [xq; yq; thetaref; vref; wref];


end
