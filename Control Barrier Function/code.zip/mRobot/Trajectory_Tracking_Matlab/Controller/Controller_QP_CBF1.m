function U = Controller_QP_CBF1(value, param)
    x = value(1);
    y = value(2);
    theta = value(3);
    
    z = value(4);
    
    xd = value(5);
    yd = value(6);
    thetad = value(7);
    vd = value(8);
    wd = value(9);
    
    theta0 = value(10);
    v0 = value(11);

    % system constraint
    vmin = param.vmin;
    vmax = param.vmax;
    wmax = param.wmax;
    m = 1;
    k1 = 1;

    fsilon = 1;
    
    gamma = 0.5;
    

    % error in body frame and change of coordinates
    R = [cos(theta) sin(theta) 0;...
        -sin(theta) cos(theta) 0;...
        0           0          1];

    X_e =double(R*[xd - x;...
        yd - y;...
        thetad - theta]);

    x0 = X_e(3);
    x1 = X_e(2);
    x2 = -X_e(1);
    
    pi1 = sqrt(x1^2 + x2^2 +1);
    
    x0_ = double(m*x0 + x1/pi1); 
    pi2 = sqrt(x0_^2 + 1);
    
    f = [((x2*wd/pi1) + ((1+x2^2)*vd*sin(x0)/pi1^3));...
        (x2*wd + vd*sin(x0));...
        -wd*x1];
    
    g = [(m-(x2/pi1))  (-x1*x2/pi1^3);...
        -x2 0;...
        x1 1];
    
    % CLF and CLF constraint calculation
    V = pi2 + k1*pi1 -(1+k1);

    V_dot = [(x0_/pi2) (k1*x1/pi1) (k1*x2/pi1)];
    
    si0 = V_dot*f + fsilon*V;
    si1 = V_dot*g;

    
     
    global Aclf_stor;
    Aclf_stor = [Aclf_stor si1'];
    
    global bclf_stor;
    bclf_stor = [bclf_stor si0];
    
    % CBF
    
    h = (z - 10);
    B = -log(h/(1+h));
    
    
    global B_stor;
    B_stor = [B_stor B];
    
    LfB = ((-v0 + vd*cos(x0)))/(h*(h+1));
    LgB = [0 1/(10*h*(h+1))];
    
    % Quadratic programming formulation
    y1 = sqrt(pi2 -1);
    y2 = sqrt(k1*pi1 - k1 );
    b1 = (m - x2/pi1)/(2*y1*pi2);
    c1 = (-x1*x2/pi1^3)/(2*y1*pi2);
    a1 = (x2*wd/pi1 + (1+x2^2)*vd*sin(x0)/pi1^3)/(2*y1*pi2);
    a2 = k1*x1*vd*sin(x0)/(2*y2*pi1);
    b2 = 0;
    c2 = 1;
    
    psc = exp(4);

    
    
    Aclf  = [si1 -1];
    bclf = -si0;
            
    Acbf = [LgB 0];
    bcbf = -LfB + (gamma/B);
    
    global const_mode;
    
    switch const_mode
        case 0
            
            A = [Aclf;Acbf];
            b = [bclf;bcbf];
                    
            
            
        case 1
            % calculating the upper and lower constraint for control output 1 and 2
            wu = wd + wmax;
            wl = wd - wmax;
            vu = vmax - vd*cos(x0);
            vl = vmin - vd*cos(x0);
            

            
            Aclf  = [si1 -1];
            bclf = -si0;
            
%             Acc = [1    0   0;...
%                 -1  0   0;...
%                 0   1   0;...
%                 0   -1  0];
%             bcc = [wu; -wl; vu; -vl];

            Acc = [1    0   0;...
                -1  0   0;...
                0   1   0];
            
            bcc = [wu; -wl; vu];
            

            A = [Aclf; Acbf; Acc];
            b = [bclf; bcbf; bcc];
            
            
        otherwise
            error('no valid mode');
    
    end
    
    
    H = 2*[(b1^2+b2^2) (b1*c1+b2*c2) 0;...
        (b1*c1+b2*c2) (c1^2+c2^2) 0;...
        0 0 psc];
    
    f = [2*(a1*b1 + a2*b2);...
        2*(a1*c1 + a2*c2);...
        0];


    [U1,~] = quadprog(H,f,A,b);
    
    u1 = wd - U1(1);
    u0 = U1(2) + vd*cos(x0);

    vc = u0;
    wc = u1;
    
    U = [vc; wc];


end

