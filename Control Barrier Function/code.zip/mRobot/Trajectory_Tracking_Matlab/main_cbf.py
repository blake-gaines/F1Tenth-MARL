import numpy as np
import math
from cvxopt import matrix, solvers
from scipy.interpolate import UnivariateSpline
import matplotlib.pyplot as plt
scale = 10
class Solver:
	def __init__(self):
		self.Aclf_stor = []
		self.Bclf_stor = []
		self.B_stor = []
		self.const_mode = 1

		# self.points = np.array([[-250, -50], [-215, -5], [-175, 40], [-115, 20], [-70, -20], [-10, -10]])
		# self.t = np.array([0, 6, 12, 18, 24, 30])
		self.points = np.array([[-250, 0], [0, 250], [250, 0], [0, -250], [-250, 0]])*1.0/scale
		self.t = np.array([0, 6, 12, 18, 24])
		
		self.points_obs = 100*np.array([[-270, 40], [-215, 40], [-175, 40], [-138, 35], [-110, 15], [-90, -10], [-70, -35], [-50, 10]])
		self.t_obs = np.array([0, 6, 12, 18, 24, 30, 36, 42])

		self.trajectory = self.getTrajectory(self.points, self.t)
		self.trajectory_obs = self.getTrajectory(self.points_obs, self.t_obs)

		self.vmin = 8
		self.vmax = 13
		self.wmax = 0.671

	def getTrajectory(self, points, t, V_init=0, V_final=0, dt=0.01, Tf=30):
		x = points[:,0]
		y = points[:,1]
		N = int(Tf*1.0/dt)
		tq = np.linspace(0, Tf, N)
		
		xpol = UnivariateSpline(t, x, k=3, s=0)
		xdpol = xpol.derivative(n=1)
		xddpol = xpol.derivative(n=2)

		xq = xpol(tq)
		xdq = xdpol(tq)
		xddq = xddpol(tq)

		ypol = UnivariateSpline(t, y, k=3, s=0)
		ydpol = ypol.derivative(n=1)
		yddpol = ypol.derivative(n=2)

		yq = ypol(tq)
		ydq = ydpol(tq)
		yddq = yddpol(tq)
		K = np.array([(xdq[i]*yddq[i] - xddq[i]*ydq[i])/math.pow(xdq[i]**2 + ydq[i]**2, 1.5) for i in range(xdq.shape[0])])
		# K = np.zeros(xq.shape[0])

		wref = K*xdq
		wref[0] = 0

		thetaref = np.array([math.atan2(ydq[i], xdq[i]) for i in range(xdq.shape[0])])
		# vref = xdq*np.array([math.cos(thetaref[i]) for i in range(thetaref.shape[0])]) + ydq*np.array([math.sin(thetaref[i]) for i in range(thetaref.shape[0])])
		vref = np.array([math.sqrt(xdq[i]*xdq[i] + ydq[i]*ydq[i]) for i in range(xdq.shape[0])])

		xq = xq.reshape((N,1))
		yq = yq.reshape((N,1))
		thetaref = thetaref.reshape((N,1))
		vref = vref.reshape((N,1))
		wref = wref.reshape((N,1))
		traj = np.hstack((xq, yq, thetaref, vref, wref)).T
		return (traj)

	def error(self, desired, actual):
		diff = desired - actual
		if (abs(diff) <= math.pi):
			return diff
		elif diff < -math.pi:
			return diff + 2*math.pi
		else:
			return diff - 2*math.pi

	def controller(self, value):
		x, y, theta, z, xd, yd, thetad, vd, wd, theta0, v0 = value
		vmin = self.vmin
		vmax = self.vmax
		wmax = self.wmax
		m = 1
		k1 = 1
		fsilon = 1
		gamma = 0.5
		R = np.array([[math.cos(theta), math.sin(theta), 0],
			[-math.sin(theta), math.cos(theta), 0], 
			[0, 0, 1]])

		X_e = R.dot(np.array([[xd-x],[yd-y],[self.error(thetad, theta)]]))
		# X_e = R.dot(np.array([[xd-x],[yd-y],[thetad-theta]]))
		x0 = X_e[2,0]
		x1 = X_e[1,0]
		x2 = -X_e[0,0]

		pi1 = math.sqrt(x1**2 + x2**2 +1)

		x0_ = m*x0 + x1/pi1
		pi2 = math.sqrt(x0_**2 + 1)

		f = np.vstack((x2*wd/pi1 + (1+x2**2)*vd*math.sin(x0)/pi1**3,
					  x2*wd + vd*math.sin(x0),
					  -wd*x1))

		g = np.array([[m-(x2/pi1), -x1*x2/pi1**3],
					  [-x2, 0],
					  [x1, 1]])

		V = pi2 +  k1*pi1 -(1+k1)

		V_dot = np.array([(x0_/pi2), (k1*x1/pi1), (k1*x2/pi1)]).reshape((1,3))

		si0 = V_dot.dot(f) + fsilon*V
		si1 = V_dot.dot(g)

		self.Aclf_stor.append(si1.T)
		self.Bclf_stor.append(si0)

		h = z-10
		B = -math.log(h/(1+h))

		self.B_stor.append(B)

		LfB =  ((-v0 + vd*math.cos(x0)))/(h*(h+1))
		LgB = np.array([[0, 1/(10*h*(h+1))]])

		y1 = math.sqrt(pi2-1)
		y2 = math.sqrt(k1*pi1 - k1)
		b1 = (m - x2/pi1)/(2*y1*pi2)
		c1 = (-x1*x2/pi1**3)/(2*y1*pi2)
		a1 = (x2*wd/pi1 + (1+x2**2)*vd*math.sin(x0)/pi1**3)/(2*y1*pi2)
		a2 = k1*x1*vd*math.sin(x0)/(2*y2*pi1)
		b2 = 0
		c2 = 1
		psc = math.exp(4)

		Aclf = np.hstack((si1, [[-1]]))
		bclf = -si0

		Acbf = np.hstack((LgB, [[0]]))
		bcbf = -LfB + (gamma/B)

		if self.const_mode == 0:
			A = matrix(np.vstack((Aclf, Acbf)))
			b = matrix(np.vstack((bclf, bcbf)))

		elif self.const_mode == 1:
			wu = wd + wmax
			wl = wd - wmax
			vu = vmax - vd*math.cos(x0)
			vl = vmin - vd*math.cos(x0)

			Acc = np.array([[1,0,0],[-1,0,0],[0,1,0]])
			bcc = np.vstack((wu, -wl, vu))

			A = matrix(np.vstack((Aclf, Acbf, Acc)))
			b = matrix(np.vstack((bclf, bcbf, bcc)))

		else:
			print('Not a valid mode')

		H = 2.0*matrix([[(b1**2+b2**2), (b1*c1+b2*c2), 0],
						[(b1*c1+b2*c2), (c1**2+c2**2), 0],
						[0, 0, psc]])

		f = 2.0*matrix(np.array([[a1*b1 + a2*b2], [a1*c1 + a2*c2], [0]]))
		solvers.options['show_progress'] = False
		U1 = solvers.qp(H,f,A,b)

		wc = wd - U1['x'][0]
		vc = U1['x'][1] + vd*math.cos(x0)

		# vc = u0
		# wc = u1

		U = np.array([vc, wc])
		return(U)


if __name__ == "__main__":
	obj = Solver()
	dt = 0.01
	Tf = 30
	s = 0
	tsteps = np.linspace(0,Tf, num=Tf*1.0/dt)
	N = tsteps.shape[0]
	X = np.zeros((4, N))
	U_plot = np.zeros((2, N))

	# X[:,0] = [-315, -10, 2.75, 0]
	X[:,0] = [-250/scale, 0.1, 1.57, 0]
	for i in range(N-1):
		X[3,i] = math.sqrt((X[0,i] - obj.trajectory_obs[0,i])**2 + (X[1,i] - obj.trajectory_obs[1,i])**2)
		U = obj.controller(np.hstack((X[:4,i], obj.trajectory[:,i], obj.trajectory_obs[2:4,i])))

		X[0,i+1] = X[0,i] + dt*U[0]*math.cos(X[2,i])
		X[1,i+1] = X[1,i] + dt*U[0]*math.sin(X[2,i])
		X[2,i+1] = X[2,i] + dt*U[1]
		if X[2,i+1] < -math.pi:
			X[2,i+1] += 2*math.pi
		if X[2,i+1] > math.pi:
			X[2,i+1] += -2*math.pi

		U_plot[:,i] = U

	plt.plot(X[0,:], X[1,:],'r', label='Actual Trajectory')
	plt.plot(obj.trajectory[0,:], obj.trajectory[1,:],'b', label='Desired Trajectory')
	plt.legend()
	plt.show()

