% close all
clear all
clc

addpath('Parameter')
addpath('Trajectory')
addpath('Controller')

% Total Time and Time Step
dt=0.01;
Tf = 30;
tsteps= 0:dt:Tf;
N=size(tsteps,2);


% get the parameters
param = get_parameter();

% uncomment to call different trajectory
% Waypoint and Time
% points = [-250 -50; -200 -35; -140 -20; -95 -40; -40 -30; 20 -10];
% t = [0 6 12 18 24 30];

% points = [0 0; 50 5; 100 8; 150 3; 200 2; 250 1];
% t = [0 6 12 18 24 30];

% Trajectory Generation Using Cubic Spline
%uncomment to derive different trajectory
% trajectory = Cubic_Spline_Curve(points,t);

%default trajectory
trajectory = Cubic_Spline_Curve();


% % initialization of initial input value 
X = zeros(6,N);
U_plot = zeros(2,N);

global Aclf_stor;
Aclf_stor = [];

global bclf_stor;
bclf_stor = [];

global B_stor;
B_stor = [];

% different initial points(first twoo for default and 1st derived
% trajectory
X(:,1) = [-315;-10;2.75;0;0;0];
% X(:,1) = [-255;-45;0;0;0;0];

% initial point for 2nd derived trajectory
% X(:,1) = [0; -10; 0; 0; 0; 0];

% choose 1 for considering input sturation else 0
%implemented for different obstacles(in this code keep the const_mode = 1)
global const_mode;
const_mode = 1;

number_obstacle = 1;

switch number_obstacle
    case 1
        % Trajectory of Front Vehicle
        Traj_des_f = Cubic_Spline_Curve(param.points_f, param.t_f);
        
    case 2
        % Trajectory of Front Vehicle
        Traj_des_f = Cubic_Spline_Curve(param.points_f, param.t_f);
        Traj_des_f2 = Cubic_Spline_Curve(param.points_f2, param.t_f2);
        
    case 3
        % Trajectory of Front Vehicle
        Traj_des_f = Cubic_Spline_Curve(param.points_f, param.t_f);
        Traj_des_f2 = Cubic_Spline_Curve(param.points_f2, param.t_f2);
        Traj_des_f3 = Cubic_Spline_Curve(param.points_f3, param.t_f3);
    otherwise
        error('no valid selection');
end


for i =1:N-1
    
    switch number_obstacle
        case 1
            % control input for desired state
            X(4,i) = ((X(1,i) - Traj_des_f(1,i))^2 + (X(2,i) - Traj_des_f(2,i))^2)^0.5;
            U = Controller_QP_CBF1([X(1:4,i); trajectory(1:5,i);Traj_des_f(3:4,i)], param);
            
        case 2
            X(4,i) = ((X(1,i) - Traj_des_f(1,i))^2 + (X(2,i) - Traj_des_f(2,i))^2)^0.5;
            X(5,i) = ((X(1,i) - Traj_des_f2(1,i))^2 + (X(2,i) - Traj_des_f2(2,i))^2)^0.5;
            U = Controller_QP_CBF2([X(1:5,i); trajectory(1:5,i);Traj_des_f(3:4,i);Traj_des_f2(3:4,i)], param);
            
        case 3
            X(4,i) = ((X(1,i) - Traj_des_f(1,i))^2 + (X(2,i) - Traj_des_f(2,i))^2)^0.5;
            X(5,i) = ((X(1,i) - Traj_des_f2(1,i))^2 + (X(2,i) - Traj_des_f2(2,i))^2)^0.5;
            X(6,i) = ((X(1,i) - Traj_des_f3(1,i))^2 + (X(2,i) - Traj_des_f3(2,i))^2)^0.5;
            U = Controller_QP_CBF3([X(1:6,i); trajectory(1:5,i);Traj_des_f(3:4,i);Traj_des_f2(3:4,i);Traj_des_f3(3:4,i)], param);           
            
        otherwise
            error('no valid selection');
    end
    % System state updates using steer command and Velocity Command
    X(1,i+1) = X(1,i)+ dt*U(1)*cos(X(3,i));
    X(2,i+1) = X(2,i)+ dt*U(1)*sin(X(3,i));
    X(3,i+1) = X(3,i)+ dt*U(2);
    
    % save input for plot
    U_plot(:,i) = U;
    
end

%% Plot

switch number_obstacle
    case 1   
        figure;
        plot(trajectory(1,:), trajectory(2,:),':r', 'LineWidth', 1);
        hold on
        plot(Traj_des_f(1,:), Traj_des_f(2,:),'-b', 'LineWidth', 1);
        axis([-350.0 70.0 -100.0 100.0]);
%         axis([-10.0 255.0 -50.0 50.0]);
        title('y vs. x');
        p = plot(X(1,1),X(2,1),'o','MarkerFaceColor','red');
        p2 = plot(Traj_des_f(1,1),Traj_des_f(2,1),'o','MarkerFaceColor','blue');

        for k = 2:length(X)
            p.XData = X(1,k);
            p.YData = X(2,k);
            p2.XData = Traj_des_f(1,k);
            p2.YData = Traj_des_f(2,k);
            drawnow
        end
        
        figure
        plot(tsteps, X(4,:),'-r', 'LineWidth', 2);
        title('Distance from front vehicle Vs Time');
        
    case 2
        figure;
        plot(trajectory(1,:), trajectory(2,:),':r', 'LineWidth', 1);
        hold on
        plot(Traj_des_f(1,:), Traj_des_f(2,:),'-b', 'LineWidth', 1);
        plot(Traj_des_f2(1,:), Traj_des_f2(2,:),'-g', 'LineWidth', 1);
        axis([-350.0 70.0 -100.0 100.0]);
%         axis([-10.0 255.0 -50.0 50.0]);
        title('y vs. x');
        p = plot(X(1,1),X(2,1),'o','MarkerFaceColor','red');
        p2 = plot(Traj_des_f(1,1),Traj_des_f(2,1),'o','MarkerFaceColor','blue');
        p3 = plot(Traj_des_f2(1,1),Traj_des_f2(2,1),'o','MarkerFaceColor','green');

        for k = 2:length(X)
            p.XData = X(1,k);
            p.YData = X(2,k);
            p2.XData = Traj_des_f(1,k);
            p2.YData = Traj_des_f(2,k);
            p3.XData = Traj_des_f2(1,k);
            p3.YData = Traj_des_f2(2,k);
            drawnow
        end
        
        figure
        plot(tsteps, X(4,:),'-r', 'LineWidth', 2);
        title('Distance from front first vehicle Vs Time');

        figure
        plot(tsteps, X(5,:),'-r', 'LineWidth', 2);
        title('Distance from front second vehicle Vs Time');
        
    case 3
        figure;
        plot(trajectory(1,:), trajectory(2,:),':r', 'LineWidth', 1);
        hold on
        plot(Traj_des_f(1,:), Traj_des_f(2,:),'-b', 'LineWidth', 1);
        plot(Traj_des_f2(1,:), Traj_des_f2(2,:),'-g', 'LineWidth', 1);
        plot(Traj_des_f3(1,:), Traj_des_f3(2,:),'-y', 'LineWidth', 1);
        axis([-350.0 70.0 -100.0 100.0]);
%         axis([-10.0 255.0 -50.0 50.0]);
        title('y vs. x');
        p = plot(X(1,1),X(2,1),'o','MarkerFaceColor','red');
        p2 = plot(Traj_des_f(1,1),Traj_des_f(2,1),'o','MarkerFaceColor','blue');
        p3 = plot(Traj_des_f2(1,1),Traj_des_f2(2,1),'o','MarkerFaceColor','green');
        p4 = plot(Traj_des_f3(1,1),Traj_des_f3(2,1),'o','MarkerFaceColor','yellow');

        for k = 2:length(X)
            p.XData = X(1,k);
            p.YData = X(2,k);
            p2.XData = Traj_des_f(1,k);
            p2.YData = Traj_des_f(2,k);
            p3.XData = Traj_des_f2(1,k);
            p3.YData = Traj_des_f2(2,k);
            p4.XData = Traj_des_f3(1,k);
            p4.YData = Traj_des_f3(2,k);
            drawnow
        end
        
        figure
        plot(tsteps, X(4,:),'-r', 'LineWidth', 2);
        title('Distance from first vehicle Vs Time');

        figure
        plot(tsteps, X(5,:),'-r', 'LineWidth', 2);
        title('Distance from second vehicle Vs Time');

        figure
        plot(tsteps, X(6,:),'-r', 'LineWidth', 2);
        title('Distance from third vehicle Vs Time');
        
    otherwise
        error('no valid selection');
        
end


figure;
plot(trajectory(1,:),trajectory(2,:),'-b');
hold on
plot(X(1,:), X(2,:),':r', 'LineWidth', 2);
title('Reference and Actual Trajectory of Vehicle');
legend('Desired Trajectory', 'Actual Trajectory');

figure
plot(tsteps, X(3,:),'-r', 'LineWidth', 2);
title('Theta Vs Time');


figure
plot(tsteps, U_plot(1,:), 'LineWidth', 2);
title('Velocity Command Vs Time');

figure
plot(tsteps, U_plot(2,:), 'LineWidth', 2);
title('Steer Command Vs Time');


