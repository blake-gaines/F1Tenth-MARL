function param = get_parameter()

    %positive control paramter 
    param.si_v = 1.5;
    param.si_w = 0.2;
    param.m = 1;

    %system constraint 
%     param.vmin = 8;
    param.vmin = 8;
    param.vmax = 13;
    param.wmax = 0.671;

    % system constant
    % set k1 = 6 for Controller_Beard and k1 = 0.3 for Controller_Rabie k1
    % = 1for CBF
    param.k1 = 1;
    param.k2 = 1;
    param.kx = 6;
    param.gamma0 = 4; 
    param.gamma1 = 6;
    param.gamma2 = 10;
    param.alphax = 4;
    param.alphas = 10;


    % CBF Parameter
    param.fsilon = 1;
    param.psc = exp(-5);

    % System Constraints (similar to Tabuada Paper)
    param.ca = 0.3;
    param.cd = 0.3;
    param.g = 9.81;

    % for 1 gamma =3 and h_mul = 10;
    % for 2 gamma = 0.15 and h_mul = 2;
    % for 3 gamma = 0.01 and h_mul = 100 psc multi = 0.001 ;
    param.gamma = 1;

    % Waypoint and Time
    param.t = [0 6 12 18 24 30];
    param.points = [-250 -50; -215 -5; -175 40; -115 20; -70 -20; -10 -10];
    
%     param.points = [0 0; 50 5; 100 8; 150 3; 200 2; 250 1];
%     param.t = [0 6 12 18 24 30];
    
    % Waypoint and Time for front Vehicle
    param.t_f = [0 6 12 18 24 30 36 42];
    param.points_f = [-270 40; -215 40; -175 40; -138 35; -110 15; -90 -10; -70 -35; -50 10];

%     param.t_f = [0 6 9 18 24 30];
%     param.points_f = [40 0; 50 6; 68 9; 150 20; 160 40; 170 40];

    
    param.t_f2 = [0 6 12 18 24 30];
    param.points_f2 = [-246 -40; -210 -2; -170 44; -110 24; -65 -18; -5 -5];

%     param.t_f2 = [0 6 12 18 22 30];
%     param.points_f2 = [110 -20; 110 -10;130 -10;150 0;175 -3;200 -40];
    
    param.t_f3 = [0 6 12 18 24 30];
    param.points_f3 = [-220 -50; -210 -5; -175 35; -120 20; -70 -25; -10 -15];

%     param.t_f3 = [0 6 12 18 22 30];
%     param.points_f3 = [130 -10; 134 -8; 136 -6; 140 -5; 165 -6; 230 -30];

end
