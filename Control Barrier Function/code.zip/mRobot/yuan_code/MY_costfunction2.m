function cost = MY_costfunction2(x,State_Initial,Np,Nc,T,X_predict,Y_predict,phi_predict,Q,R) 
    cost=0;  
    X=State_Initial(1,1);
    Y=State_Initial(2,1);
    phi=State_Initial(3,1);

    X_predict1=zeros(Np,1);
    Y_predict1=zeros(Np,1);
    phi_predict1=zeros(Np,1);
      
    Y_error=zeros(Np+1,1);
    X_error=zeros(Np+1,1);
    phi_error=zeros(Np+1,1);
    
    u1=zeros(Np,1); 
    r1=zeros(Np,1);
 for i=1:1:Np
        if i==1 
            u1(i,1)=x(1);
            r1(i,1)=x(2);
            X_predict1(i,1)=X+T*(u1(i,1)*cos(phi));  
            Y_predict1(i,1)=Y+T*(u1(i,1)*sin(phi)); 
            phi_predict1(i,1)=phi+T*r1(i,1);         
        else            
            u1(i,1)=x(3);
            r1(i,1)=x(4);
            X_predict1(i,1)=X_predict1(i-1,1)+T*(u1(i,1)*cos(phi_predict1(i-1,1)));
            Y_predict1(i,1)=Y_predict1(i-1,1)+T*(u1(i,1)*sin(phi_predict1(i-1,1)));
            phi_predict1(i,1)=phi_predict1(i-1,1)+T*r1(i,1);
        end
        X_real=zeros(Np+1,1);
        Y_real=zeros(Np+1,1);
        phi_real=zeros(Np+1,1);
        X_real(1,1)=X;
        X_real(2:Np+1,1)=X_predict1;
        Y_real(1,1)=Y;
        Y_real(2:Np+1,1)=Y_predict1;
        phi_real(1,1)=phi;
        phi_real(2:Np+1,1)=phi_predict1;              
        Y_error(i,1)=Y_real(i,1)-Y_predict(i,1);
        X_error(i,1)=X_real(i,1)-X_predict(i,1);
        phi_error(i,1)=phi_real(i,1)-phi_predict(i,1);
    end 
        cost=cost+Y_error'*R*Y_error+X_error'*Q*X_error+phi_error'*Q*phi_error;% End of CostFunction
