clc;
clear all;
%% generation for the reference trajectory
N=300;
T=0.1;
Xout=zeros(N,3);
Tout=zeros(N,1);
for k=1:1:N
    Tout(k,1)=(k-1)*T;
end
tra = [];
tra =xlsread('trajectory5.xlsx');
X1out=tra(2:4,1:300);
Xout=X1out';
X1out2=tra(5:6,1:300);
Xout2=X1out2';
% Tracking a constant reference trajectory
Nx=3;
Nu =2;
Np1=15;
Nc1=2;
X0 = [-13 -2  0];
[Nr,Nc] = size(Xout); % Nr is the number of rows of Xout
% vd1 = 0.65; % the desired velocity
% vd2 = 0;
x_real=zeros(Nr,Nc);
x_piao=zeros(Nr,Nc);
u_real=zeros(Nr,2);
u_piao=zeros(Nr,2);
x_real(1,:)=X0;
x_piao(1,:)=x_real(1,:)-Xout(1,:);
X_PIAO=zeros(Nr,Nx*Np1);
XXX=zeros(Nr,Nx*Np1);
q=[1 0 0;0 1 0;0 0 0.05];
Q_cell=cell(Np1,Np1);
for i=1:1:Np1
    for j=1:1:Np1
        if i==j
            Q_cell{i,j}=q;
        else 
            Q_cell{i,j}=zeros(Nx,Nx);
        end 
    end
end
Q=cell2mat(Q_cell);
R=0.1*eye(Nu*Nc1,Nu*Nc1);
for i=1:1:Nr
    t_d =Xout(i,3);
    vd1 =Xout2(i,1);
    vd2 =Xout2(i,2);
    a=[1    0   -vd1*sin(t_d)*T;
       0    1   vd1*cos(t_d)*T;
       0    0   1;];
    b=[cos(t_d)*T   0;
       sin(t_d)*T   0;
       0            T;];     
    A_cell=cell(Np1,1);
    B_cell=cell(Np1,Nc1);
     for j=1:1:Np1
        A_cell{j,1}=a^j;
        for k=1:1:Nc1
           if k<=j
                B_cell{j,k}=(a^(j-k))*b;
           else
                B_cell{j,k}=zeros(Nx,Nu);
           end
        end
    end
    A=cell2mat(A_cell);
    B=cell2mat(B_cell);
    H=2*(B'*Q*B+R);
    f=2*B'*Q*A*x_piao(i,:)';
    A_cons=[];
    b_cons=[];
    vmax=0.65;vmin=0;wmax=1;wmin=-1;
    wu = wmax - vd2;
    wl = wmin - vd2;
    vu = vmax - vd1;
    vl = vmin - vd1;
    lb=[vl;wl];
    ub=[vu;wu];
    tic
    [X,fval(i,1),exitflag(i,1),output(i,1)]=quadprog(H,f,A_cons,b_cons,[],[],lb,ub);
    toc
    X_PIAO(i,:)=(A*x_piao(i,:)'+B*X)';
    if i+j<Nr
         for j=1:1:Np1
             XXX(i,1+3*(j-1))=X_PIAO(i,1+3*(j-1))+Xout(i+j,1);
             XXX(i,2+3*(j-1))=X_PIAO(i,2+3*(j-1))+Xout(i+j,2);
             XXX(i,3+3*(j-1))=X_PIAO(i,3+3*(j-1))+Xout(i+j,3);
         end
    else
         for j=1:1:Np1
             XXX(i,1+3*(j-1))=X_PIAO(i,1+3*(j-1))+Xout(Nr,1);
             XXX(i,2+3*(j-1))=X_PIAO(i,2+3*(j-1))+Xout(Nr,2);
             XXX(i,3+3*(j-1))=X_PIAO(i,3+3*(j-1))+Xout(Nr,3);
         end
    end
    u_piao(i,1)=X(1,1);
    u_piao(i,2)=X(2,1);
    X00=x_real(i,:);
    vd11=vd1+u_piao(i,1);
    vd22=vd2+u_piao(i,2);
    XOUT=dsolve('Dx-vd11*cos(z)=0','Dy-vd11*sin(z)=0','Dz-vd22=0','x(0)=X00(1)','y(0)=X00(2)','z(0)=X00(3)');
     t=T; 
     x_real(i+1,1)=eval(XOUT.x);
     x_real(i+1,2)=eval(XOUT.y);
     x_real(i+1,3)=eval(XOUT.z);
     if(i<Nr)
         x_piao(i+1,:)=x_real(i+1,:)-Xout(i+1,:);
     end
    u_real(i,1)=vd1+u_piao(i,1);
    u_real(i,2)=vd2+u_piao(i,2);
    
    figure(1);
    plot(Xout(1:Nr,1),Xout(1:Nr,2));
    hold on;
    plot(x_real(i,1),x_real(i,2),'r*');
    title('The results of trajectory tracking');
    xlabel('X');
    axis([-13 0 -3 3]);
    ylabel('Y');
    hold on;
    for k=1:1:Np1
         X(i,k+1)=XXX(i,1+3*(k-1));
         Y(i,k+1)=XXX(i,2+3*(k-1));
    end
    X(i,1)=x_real(i,1);
    Y(i,1)=x_real(i,2);
    plot(X(i,:),Y(i,:),'y')
    hold on;
    
end

figure(2)
subplot(3,1,1);
plot(Tout(1:Nr),Xout(1:Nr,1),'k--');
hold on;
plot(Tout(1:Nr),x_real(1:Nr,1),'k');
title('The comparison of states');
% xlabel('Sample time/s');
ylabel('X')
subplot(3,1,2);
plot(Tout(1:Nr),Xout(1:Nr,2),'k--');
hold on;
plot(Tout(1:Nr),x_real(1:Nr,2),'k');
% xlabel('Sample time/s');
ylabel('Y')
subplot(3,1,3);
plot(Tout(1:Nr),Xout(1:Nr,3),'k--');
hold on;
plot(Tout(1:Nr),x_real(1:Nr,3),'k');
hold on;
xlabel('Sample time/s');
ylabel('\theta')

figure(3)
subplot(2,1,1);
plot(Tout(1:Nr),u_real(1:Nr,1),'k');
title('The comparison of control input');
% xlabel('Sample time/s');
ylabel('u')
subplot(2,1,2)
plot(Tout(1:Nr),u_real(1:Nr,2),'k');
xlabel('Samle time/s');
ylabel('w')

figure(4)
subplot(3,1,1);
plot(Tout(1:Nr),x_piao(1:Nr,1),'k');
title('The deviation of states');
% xlabel('Samle time/s');
ylabel('e(x)');
subplot(3,1,2);
plot(Tout(1:Nr),x_piao(1:Nr,2),'k');
% xlabel('Samle time/s');
ylabel('e(y)');
subplot(3,1,3);
plot(Tout(1:Nr),x_piao(1:Nr,3),'k');
%grid on;
xlabel('Samle time/s');
ylabel('e(\theta)');


