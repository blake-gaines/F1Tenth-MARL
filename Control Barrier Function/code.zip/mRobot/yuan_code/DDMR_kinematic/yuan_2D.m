 
clc;
clear all;

%% Initialiazaion
tic
Nx=3;
Np=9;
Nc=2;
N=1600;
T=0.05;
S=100;

kv=12;%Backstepping control parameters
ki=12;
kz=10;

State_Initial=zeros(Nx,1);
State_Initial(1,1)=0;%x 
State_Initial(2,1)=-5;%y
State_Initial(3,1)=pi/4;%phi

X0=0;
Y0=-5;
PSI0=pi/4;

Q1=100*eye(Np,Np);
R1=20*eye(Nc,Nc);  
Q=100*eye(Np+1,Np+1);
R=100*eye(Np+1,Np+1);
Xout=zeros(N,3);%Gloable trajetory
T_out=zeros(N,1);
for k=1:1:N
    Xout(k,1)=10*sin(0.08*k*T);
    Xout(k,2)=-10*cos(0.08*k*T);
    Xout(k,3)=0.08*k*T;
    T_out(k,1)=1*(k-1)*T;
end

%% Start to solve
for j=1:1:N
   %Global trajectory
   Xref=zeros(Np,1);
   Yref=zeros(Np,1);
   phiref=zeros(Np,1);
   Tout=zeros(Np,1);    
    for Nref=1:1:Np   
        Xref(Nref,1)=10*sin(0.08*(j+Nref-1)*T);
        Yref(Nref,1)=-10*cos(0.08*(j+Nref-1)*T);
        phiref(Nref,1)=0.08*(j+Nref-1)*T;
        Tout(Nref,1)=1*(j+Nref-1)*T;
    end
    %% Obstacle setting
   Nobs=9;
    X_obstacle=zeros(Nobs,1);
    X_obstacle(1:2)=-10.5;
    X_obstacle(3:4)=-10;
    X_obstacle(5:6)=-9.5; 
    
    X_obstacle(7)=0;
    X_obstacle(8)=10;
    X_obstacle(9)=0;
    
    Y_obstacle=zeros(Nobs,1); 
    Y_obstacle(1)=0.2;
    Y_obstacle(2)=-0.2;
    Y_obstacle(3)=0.2;
    Y_obstacle(4)=-0.2;
    Y_obstacle(5)=0.2;
    Y_obstacle(6)=-0.2;
    
    Y_obstacle(7)=-10.5;
    Y_obstacle(8)=0;
    Y_obstacle(9)=6;
    
ob1=[-5.5 -4.5 -4.5 -5.5];ob2=[0.2 0.2 -0.2 -0.2];

  %% Replanner
    lb=[-0.9;-1;-0.9;-1];
    ub=[0.9;1;0.9;1];
    A=[];
    b=[];
    Aeq=[];
    beq=[];
    options = optimset('Algorithm','active-set');                             
    [a,fval,exitflag]=fmincon(@(x)MY_costfunction1(x,State_Initial,Np,Nc,Nobs,T,Xref,Yref,phiref,Q1,R1,S,X_obstacle,Y_obstacle),[0;0;0;0;],A,b,Aeq,beq,lb,ub,[],options);%��Լ����⣬���ٶ���
    X_predict=zeros(Np,1);
    Y_predict=zeros(Np,1);
    phi_predict=zeros(Np,1);
            u1=zeros(Np,1);
            r1=zeros(Np,1);    
   for i=1:1:Np
        if i==1 
            u1(i,1)=a(1);  
            r1(i,1)=a(2);
            X_predict(i,1)=State_Initial(1,1)+T*(u1(i,1)*cos(State_Initial(3,1)));
            Y_predict(i,1)=State_Initial(2,1)+T*(u1(i,1)*sin(State_Initial(3,1)));
            phi_predict(i,1)=State_Initial(3,1)+T*r1(i,1);
         else 
            u1(i,1)=a(3);
            r1(i,1)=a(4); 
            X_predict(i,1)=X_predict(i-1,1)+T*(u1(i,1)*cos(phi_predict(i-1,1)));
            Y_predict(i,1)=Y_predict(i-1,1)+T*(u1(i,1)*sin(phi_predict(i-1,1)));
            phi_predict(i,1)=phi_predict(i-1,1)+T*r1(i,1);
        end 
   end
   xplanned(j,1)=X_predict(1,1);
   yplanned(j,1)=Y_predict(1,1);
   phiplanned(j,1)=phi_predict(1,1);
   
   
    %% Backstepping controller
    xcd(j)=X_predict(1,1);
    ycd(j)=Y_predict(1,1);
    Id(j)=phi_predict(1,1);  
    tout(j,1)=(j-1)*T;
    
    ud(j) = u1(1,1);
    rd(j) = r1(1,1);
if j==1
    xc(j)=0;yc(j)=-5;I(j)=pi/4; 
    uc(j)=5;;rc(j)=1;  
    exx(j)=0;ey(j)=-5;eI(j)=-0.79; 
else
    uc(j)=ud(j)+kv*(exx(j-1)*cos(I(j-1))+ey(j-1)*sin(I(j-1)));  
    rc(j)=rd(j)+ki*sin(eI(j-1)/2)+2*ud(j)*(ey(j-1)*cos((Id(j-1)+I(j-1))/2)-exx(j-1)*sin((Id(j-1)+I(j-1))/2));
    dxc(j)=uc(j)*cos(I(j-1));
    dyc(j)=uc(j)*sin(I(j-1));
    dI(j)=rc(j);

    xc(j)=dxc(j)*T+xc(j-1);     
    yc(j)=dyc(j)*T+yc(j-1);
    I(j)=dI(j)*T+I(j-1);

    exx(j)=xcd(j)-xc(j); 
    ey(j)=ycd(j)-yc(j);
    eI(j)=Id(j)-I(j); 
end
   
   %% Trajetory tracking controller
    lb=[-0.9;-1;-0.9;-1];
    ub=[0.9;1;0.9;1];
    A=[];
    b=[];
    Aeq=[];
    beq=[];
    [x,fval,exitflag]=fmincon(@(x)MY_costfunction2(x,State_Initial,Np,Nc,T,X_predict,Y_predict,phi_predict,Q,R),[0;0;0;0;],A,b,Aeq,beq,lb,ub,[],options);%��Լ����⣬���ٶ���   
    u11=x(1);
    r11=x(2);

    X00(1)=State_Initial(1,1);
    X00(2)=State_Initial(2,1);
    X00(3)=State_Initial(3,1);
    XOUT=dsolve('Dx-u11*cos(z)=0','Dy-u11*sin(z)=0','Dz-r11=0','x(0)=X00(1)','y(0)=X00(2)','z(0)=X00(3)');
    t=T;
    State_Initial(1,1)=eval(XOUT.x);
    State_Initial(2,1)=eval(XOUT.y);
    State_Initial(3,1)=eval(XOUT.z);

    State_x(j,1)=eval(XOUT.x);
    State_y(j,1)=eval(XOUT.y);
    State_psi(j,1)=eval(XOUT.z);

    u_real(j,1)=u11;
    r_real(j,1)=r11;
  
end 
 toc
 