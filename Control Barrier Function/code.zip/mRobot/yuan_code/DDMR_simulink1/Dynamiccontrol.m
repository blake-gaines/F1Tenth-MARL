function [sys,x0,str,ts] =Dynamiccontrol(t,x,u,flag)
switch flag,
case 0,
    [sys,x0,str,ts]=mdlInitializeSizes;
case 3,
    sys=mdlOutputs(t,x,u);
case {2,4,9}
    sys=[];
otherwise
    error(['Unhandled flag = ',num2str(flag)]);
end
function [sys,x0,str,ts]=mdlInitializeSizes
sizes = simsizes;
sizes.NumContStates  = 0;
sizes.NumDiscStates  = 0;
sizes.NumOutputs     = 2;
sizes.NumInputs      = 4;
sizes.DirFeedthrough = 1;
sizes.NumSampleTimes = 1;
sys = simsizes(sizes);
x0  = [];
str = [];
ts  = [0.1 0];
function sys=mdlOutputs(t,x,u)
Iz=0.10392;m=6.7;  %paameters for dynamic model
Xdu=0.403;Ndr=0.0053;
Xu=0.39;Nr=0.020;
vc=[u(1);u(2)];
dvc=[u(3);u(4)];
M=[m+Xdu 0;0 Iz+Ndr];   %the moment of inertia
D=[Xu 0;0 Nr];%the friction matrix
M0=1*M;
D0=1*D;
toleq=M0*dvc+D0*vc;   
sys(1)=toleq(1);
sys(2)=toleq(2);
