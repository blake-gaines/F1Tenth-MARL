function [sys,x0,str,ts]=DDMRmodel(t,x,u,flag)
switch flag,
case 0           % initializations
    [sys,x0,str,ts] = mdlInitializeSizes;
case 2           % discrete states updates
    sys = mdlUpdates(x,u);
case 3           % computation of control signal
    sys=mdlOutputs(t,x,u);
case {1, 4, 9}   % unused flag values
    sys = [];
otherwise        % error handling
    error(['Unhandled flag = ',num2str(flag)]);
end;
%==============================================================
% when flag=0, perform system initialization
%==============================================================
function [sys,x0,str,ts] = mdlInitializeSizes
sizes = simsizes;        % read default control variables
sizes.NumContStates = 0; % no continuous states
sizes.NumDiscStates = 3; % 3 states
sizes.NumOutputs = 3;    % 3 output variables
sizes.NumInputs = 2;     % 5 input signals
sizes.DirFeedthrough = 0;% input reflected directly in output
sizes.NumSampleTimes = 1;% single sampling period
sys = simsizes(sizes);   % 
x0 = [-13;-2;0];          % initial states
str = []; 
ts = [0.1 0];             % sampling period
%==============================================================
% when flag=2, updates the discrete states
%==============================================================
function sys = mdlUpdates(x,u)
T=0.1;
u1=u(1);
r=u(2);
x1=x(1);
y=x(2);
psi=x(3);
dx1=cos(psi)*u1;
dy=sin(psi)*u1;
dpsi=r;
sys(1)=x(1)+(cos(psi)*u1)*T;
sys(2)=x(2)+(sin(psi)*u1)*T;
sys(3)=x(3)+(r)*T;
%==============================================================
% when flag=3, computates the output signals
%==============================================================
function sys = mdlOutputs(t,x,u)
   x1=x(1);
   y=x(2);
   psi=x(3);
sys(1)=x1;sys(2)=y;sys(3)=psi;