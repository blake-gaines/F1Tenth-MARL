function [sys,x0,str,ts]=DDMRDynamicmodel(t,x,u,flag)
switch flag,
case 0,
    [sys,x0,str,ts]=mdlInitializeSizes;
case 2           % discrete states updates
    sys = mdlUpdates(x,u);
case 3,
    sys=mdlOutputs(t,x,u);
case {1, 4, 9 }
    sys = [];
otherwise
    error(['Unhandled flag = ',num2str(flag)]);
end
function [sys,x0,str,ts]=mdlInitializeSizes
sizes = simsizes;
sizes.NumContStates  = 0;
sizes.NumDiscStates  = 2;
sizes.NumOutputs     = 2;
sizes.NumInputs      = 2;
sizes.DirFeedthrough = 0;
sizes.NumSampleTimes = 1;
sys=simsizes(sizes);
x0=[0;0];
str=[];
ts = [0.1 0];             % sampling period
function sys = mdlUpdates(x,u)
Iz=0.10392;m=6.7;  %the parameters of the dynamic model
Xdu=0.403;Ndr=0.0053;
Xu=0.39;Nr=0.020;
T1=u(1);
T2=u(2);
tol=[T1;T2];       
T=0.1;
sys(1)=(tol(1)-Xu*x(1))*T/(m+Xdu)+x(1);
sys(2)=(tol(2)-Nr*x(2))*T/(Iz+Ndr)+x(2);
function sys=mdlOutputs(t,x,u)
   u1=x(1);
   r=x(2);
sys(1)=u1;sys(2)=r;
