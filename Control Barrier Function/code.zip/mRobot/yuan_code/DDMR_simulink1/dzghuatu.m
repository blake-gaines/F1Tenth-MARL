
close all;
obx1=-9.5;oby1=1;
figure(1);
plot(ud(:,1),ud(:,2),'k:','LineWidth',2.1);
hold on;
plot(ref(:,1),ref(:,2),'b','LineWidth',2.0);
hold on;
plot(obx1,oby1,'ko','LineWidth',2.1);
xlabel('x(m)','Fontsize',10);
ylabel('y(m)','Fontsize',10);
legend('Reference Trajectory','MPC Trajectory','obstacle')
axis([-13 0 -3 3]);

figure(2)
subplot(3,1,1);
plot(t,ud(:,1),'k--');
hold on;
plot(t,u(:,1),'k');
% xlabel('Sampling Time[s]');
ylabel('X')
title('Sate comparison');
axis([0 30 -13 0]);
subplot(3,1,2);
plot(t,ud(:,2),'k--');
hold on;
plot(t,u(:,2),'k');
% xlabel('Sampling Time[s]');
ylabel('Y')
axis([0 30 -3 3]);
subplot(3,1,3);
plot(t,ud(:,3),'k--');
hold on;
plot(t,u(:,3),'k');
hold on;
xlabel('Sampling Time[s]');
ylabel('\theta')
axis([0 30 -3 3]);

figure(3)
subplot(2,1,1);plot(t,u1(:,1),'-','LineWidth',2);
ylabel('u (m/s)');
title('Kinematics Velocity');
axis([0 30 -1 1]);
subplot(2,1,2);plot(t,u1(:,2),'-','LineWidth',2);
xlabel('Sampling Time[s]');
ylabel('r (rad/s)');
axis([0 30 -3.5 3.5]);





