function [sys,x0,str,ts] = MY_MPCController3(t,x,u,flag)
switch flag,
 case 0
  [sys,x0,str,ts] = mdlInitializeSizes; % Initialization
 case 2
  sys = mdlUpdates(t,x,u); % Update discrete states
 case 3
  sys = mdlOutputs(t,x,u); % Calculate outputs
 case {1,4,9} % Unused flags
  sys = [];
 otherwise
  error(['unhandled flag = ',num2str(flag)]); % Error handling
end
% End of dsfunc.
%==============================================================
% Initialization
%==============================================================
function [sys,x0,str,ts] = mdlInitializeSizes
% Call simsizes for a sizes structure, fill it in, and convert it 
% to a sizes array.
sizes = simsizes;
sizes.NumContStates  = 0;
sizes.NumDiscStates  = 3;
sizes.NumOutputs     = 5;
sizes.NumInputs      = 3;
sizes.DirFeedthrough = 1; 
sizes.NumSampleTimes = 1;
sys = simsizes(sizes); 
x0 =[-13;-2;1;];   
global U;
U=[0;0;0]; 
% Initialize the discrete states.
str = [];             % Set str to an empty matrix.
ts  = [0.1 0];       % sample time: [period, offset]
%End of mdlInitializeSizes   
%==============================================================
% Update the discrete states
%==============================================================
function sys = mdlUpdates(t,x,u)
  
sys = x;
%End of mdlUpdate.

%==============================================================
% Calculate outputs
%==============================================================
function sys = mdlOutputs(t,x,u)
    tic
    Nx=3;%the number of state
    Np =15;%prediction step length
    Nc=2;%contorl step length
    N=300;
    T=0.1;
    S=10;    
    X=u(1);
    Y=u(2);
    phi=u(3);  
    State_Initial=zeros(Nx,1);%state=[x y psi],intial value
    State_Initial(1,1)=X;%x 
    State_Initial(2,1)=Y;%y
    State_Initial(3,1)=phi;%phi
    Q1=100*eye(Np,Np); %weigh matrix of planner
    R1=15*eye(Nc,Nc);  %weigh matrix of planner
    Q=100*eye(Np+1,Np+1);%weigh matrix of tracking controller
    R=100*eye(Np+1,Np+1);%weigh matrix of tracking controller

%% start to replanning
   tra = [];
   tra =xlsread('trajectory.xlsx');
   Xref=zeros(Np,1);
   Yref=zeros(Np,1);
   phiref=zeros(Np,1);
   Tout=zeros(Np,1);    
    for Nref=1:1:Np  
         TT=round((t+Nref*T-1*T)*10)/10;
         if (TT<30)
             Xref(Nref,1)=tra(2,find(tra(1,:)==(TT)));
             Yref(Nref,1)=tra(3,find(tra(1,:)==(TT)));
             phiref(Nref,1)=tra(4,find(tra(1,:)==(TT)));
         else
             Xref(Nref,1)=tra(2,find(tra(1,:)==(30)));
             Yref(Nref,1)=tra(3,find(tra(1,:)==(30)));
             phiref(Nref,1)=tra(4,find(tra(1,:)==(30)));
         end
         Tout(Nref,1)=(TT);
    end         
 %% the setting for obstacles    
    Nobs=1;
    X_obstacle=zeros(Nobs,1);
    X_obstacle(1)=-9.5;  
    Y_obstacle=zeros(Nobs,1); 
    Y_obstacle(1)=1;
  
   %% output of the replannning results   
    lb=[0;-1;0;-1];
    ub=[0.65;1;0.65;1];
    A=[];
    b=[];
    Aeq=[];
    beq=[];
    options = optimset('Algorithm','active-set');                             
    [a,fval,exitflag]=fmincon(@(x)MY_costfunction1(x,State_Initial,Np,Nc,Nobs,T,Xref,Yref,phiref,Q1,R1,S,X_obstacle,Y_obstacle),[0;0;0;0],A,b,Aeq,beq,lb,ub,[],options);%��Լ����⣬���ٶ���
    X_predict=zeros(Np,1);
    Y_predict=zeros(Np,1);
    phi_predict=zeros(Np,1);
            u1=zeros(Np,1);
            r1=zeros(Np,1);             
   for i=1:1:Np
        if i==1 
            u1(i,1)=a(1); 
            r1(i,1)=a(2);           
            X_predict(i,1)=State_Initial(1,1)+T*(u1(i,1)*cos(State_Initial(3,1)));
            Y_predict(i,1)=State_Initial(2,1)+T*(u1(i,1)*sin(State_Initial(3,1)));
            phi_predict(i,1)=State_Initial(3,1)+T*r1(i,1);
         else 
            u1(i,1)=a(3);
            r1(i,1)=a(4);      
            X_predict(i,1)=X_predict(i-1,1)+T*(u1(i,1)*cos(phi_predict(i-1,1)));
            Y_predict(i,1)=Y_predict(i-1,1)+T*(u1(i,1)*sin(phi_predict(i-1,1)));
            phi_predict(i,1)=phi_predict(i-1,1)+T*r1(i,1);
        end 
   end
   xref=(X_predict(1,1)+State_Initial(1,1))/2;
   yref=(Y_predict(1,1)+State_Initial(2,1))/2;
   phiref=(phi_predict(1,1)+State_Initial(3,1))/2;
   
    %% trajectory tracking controller
    lb=[0;-1;0;-1];
    ub=[0.65;1;0.65;1];
    A=[];
    b=[];
    Aeq=[];
    beq=[];
    [x,fval,exitflag]=fmincon(@(x)MY_costfunction2(x,State_Initial,Np,Nc,T,X_predict,Y_predict,phi_predict,Q,R),[0;0;0;0;],A,b,Aeq,beq,lb,ub,[],options);%��Լ����⣬���ٶ���   
    u11=x(1);
    r11=x(2);
    sys(1)=X_predict(1,1);sys(2)=Y_predict(1,1);sys(3)=phi_predict(1,1);
    sys(4)=u11;sys(5)=r11;
 toc
 

 