function cost = MY_costfunction1(x,State_Initial,Np,Nc,Nobs,T,Xref,Yref,phiref,Q1,R1,S,X_obstacle,Y_obstacle)
    cost=0;  
    X=State_Initial(1,1);
    Y=State_Initial(2,1);
    phi=State_Initial(3,1);

    X_predict=zeros(Np,1);
    Y_predict=zeros(Np,1);
    phi_predict=zeros(Np,1);
      
    Y_error=zeros(Np,1);
    X_error=zeros(Np,1);
    phi_error=zeros(Np,1);
    J_obst=zeros(Np,1);
    
    u1=zeros(Np,1); 
    r1=zeros(Np,1);
  for i=1:1:Np
        if i==Nc-1 
            u1(i,1)=x(1);
            r1(i,1)=x(2);
            X_predict(i,1)=X+T*(u1(i,1)*cos(phi));
            Y_predict(i,1)=Y+T*(u1(i,1)*sin(phi));
            phi_predict(i,1)=phi+T*r1(i,1);         
            for j=1:1:Nobs
                J_obst(i,1)=J_obst(i,1)+1/(((X_predict(i,1))-X_obstacle(j,1))^2+(Y_predict(i,1)-Y_obstacle(j,1))^2+0.000001);
            end
        else            
            u1(i,1)=x(3);
            r1(i,1)=x(4);
            X_predict(i,1)=X_predict(i-1,1)+T*(u1(i,1)*cos(phi_predict(i-1,1)));
            Y_predict(i,1)=Y_predict(i-1,1)+T*(u1(i,1)*sin(phi_predict(i-1,1)));
            phi_predict(i,1)=phi_predict(i-1,1)+T*r1(i,1);
            for p=1:1:Nobs
                J_obst(i,1)=J_obst(i,1)+1/(((X_predict(i,1))-X_obstacle(p,1))^2+(Y_predict(i,1)-Y_obstacle(p,1))^2+0.000001);
            end
        end
        Y_error(i,1)=Y_predict(i,1)-Yref(i,1);
        X_error(i,1)=X_predict(i,1)-Xref(i,1);
        phi_error(i,1)=phi_predict(i,1)-phiref(i,1);
    end 
        cost=cost+Y_error'*Q1*Y_error+X_error'*Q1*X_error+phi_error'*Q1*phi_error+u1(1:2,1)'*R1*u1(1:2,1)+r1(1:2,1)'*R1*r1(1:2,1)+S*sum(J_obst(:));
      % End of CostFunction
