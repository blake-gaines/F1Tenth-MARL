    %Obstacle information
    L1=0.1;L2=2;H1=8;H2=2;
    ob1=[-12 -9.5 -9.5 -12];ob2=[0.2 0.2 -0.2 -0.2];
    X_obstacle1=0;
    Y_obstacle1=-11;
    X_obstacle2=10;
    Y_obstacle2=0;
    X_obstacle3=0;
    Y_obstacle3=6;
    % Global reference speed
    ud=5;
    vd=0;
    rd=1;
    %Trajetory tracking and avoid static obstacles
    xref(1:30,1)=Xout(1:30,1);xref(30:300,1)=xplanned(30:300,1);
    yref(1:30,1)=Xout(1:30,2);yref(30:300,1)=yplanned(30:300,1);
    phiref(1:30,1)=Xout(1:30,3); phiref(30:300,1)=phiplanned(30:300,1);
    figure(1) 
    plot(xplanned(:,1),yplanned(:,1),'k','LineWidth',2.2);
    hold on;plot(xc,yc,'r:','LineWidth',2.0);
    hold on;plot(State_x(:,1),State_y(:,1),'b--','LineWidth',2.0);
    hold on;fill(ob1,ob2,'k');
    hold on;
    plot(X_obstacle1,Y_obstacle1,'kO',X_obstacle2,Y_obstacle2,'kO',X_obstacle3,Y_obstacle3,'kO','LineWidth',2.3);
    grid on;
    legend('Re-planned Trajectory','Backstepping','Model Predictive Control','Obstacles')
    xlabel('x(m)');ylabel('y(m)');
    text(0,-5,'Start A');
    text(0.5,-10.5,'B');
    gtext('1');
    gtext('2');
    gtext('3');
    gtext('4');
    axis([-13 12 -13 12]);
    %Replanning trajetory
    figure(2)
    plot(Xout(:,1),Xout(:,2),'k','LineWidth',2.2);
    hold on;fill(ob1,ob2,'k');
    hold on;
    plot(X_obstacle1,Y_obstacle1,'kO',X_obstacle2,Y_obstacle2,'kO',X_obstacle3,Y_obstacle3,'kO','LineWidth',2.3);
   % grid on;
    legend('Re-planned Trajectory','Obstacles')
    xlabel('x(m)');ylabel('y(m)');
    text(0.5,-10.5,'B');
    gtext('1');
    gtext('2');
    gtext('3');
    gtext('4');
    axis([-13 12 -13 12]);
    %Speed comparation
    figure(3)
    subplot(2,1,1)
    plot(T_out(:,1),uc/8,'r--',T_out(:,1),u_real/8,'b','linewidth',2.0);
    text(0.05,-5.8,'C');
    text(0.1,3,'D');
    %grid on;
    ylabel('u/(m/s)');xlabel('t/(s)');
    legend('Backstepping','Model Predictive Control');
    axis([0 15 -6 4]);
    subplot(2,1,2)
    plot(T_out(:,1),rc/8,'r--',T_out(:,1),r_real/8,'b','linewidth',2.0);
    text(0.05,3,'C');
    text(0.1,-1.1,'D');
    %grid on;
    ylabel('r/(rad/s)');xlabel('t/(s)');
    axis([0 15 -2 4]);
    [xx,yy]=meshgrid(T_out(:,1),uc(:)/8);
    xx=xx(:);
    yy=yy(:);
    [mm,nn]=meshgrid(T_out(:,1),u_real(:)/8);
    mm=mm(:);
    nn=nn(:);
    [pp,zz]=meshgrid(T_out(:,1),rc(:)/8);
    pp=pp(:);
    zz=zz(:);
    [ll,jj]=meshgrid(T_out(:,1),r_real(:)/8);
    ll=ll(:);
    jj=jj(:);
    %Speed increment comparation
    i=1;
    quc(i)=0;qrc(i)=0;
    qum(i)=0;qrm(i)=0;
for i=2:1:1600
    quc(i)=yy(i)-yy(i-1);
    qum(i)=nn(i)-nn(i-1);
    qrc(i)=zz(i)-zz(i-1);
    qrm(i)=jj(i)-jj(i-1);
end  
figure(4)
subplot(2,1,1);
qumax(1:1600)=6;
qumin(1:1600)=-6;
plot(T_out(:,1),quc(:),'r--',T_out(:,1),qum(:),'b','LineWidth',2);
ylabel('��u (m/s)');
axis([0 15 -10 10]);
legend('Backstepping','Model Predictive Control')
subplot(2,1,2);
qrmax(1:1600)=2;
qrmin(1:1600)=-2;
plot(T_out(:,1),qrc(:),'r--',T_out(:,1),qrm(:),'b','LineWidth',2);
xlabel('Sampling Time t/(s)');
ylabel('��r (m/s)');
axis([0 15 -4 4]);

