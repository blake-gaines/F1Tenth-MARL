
from cvxopt import matrix, solvers
import math
import numpy as np

'''
Calculation for input using control Luapunov function(CLF)
and control barrier function(CBF) for safety aware ACC
'''

'''
system constant
'''
vd = 24.0		# Desire velocity of front vehicle (m/s)
v0 = 10.0		# Front vehicle velocity (m/s)

m = 1650.0		# mass of ego vehicle (kg)
ca = 0.3		# max acceleration ca*g
cd = 0.3		# max deacceleration -cd*g
g = 9.81		# gravitational acceleration

fsilon = 5.0	# coeff to Exponential CLF
gamma = 1.0		# Coeff to exponential CBF
x0 = 0.5		# Stopping distance from front vehicle
	
f0 = 0.1		# Coeff for aerodynamic drag
f1 = 5.0
f2 = 0.25



def FR(x2):
	'''
	aerodynamic drag force for given velocity(x2)
	'''
	Fr = f0 + f1*x2 + f2*(x2**2)
	return Fr


def Si_0(x2):
	'''
	calculation of si0 for Lyapunov Constraints
	'''
	Fr = FR(x2)
	si0 = -2.0*((x2 - vd)*Fr/m) + fsilon*((x2-vd)**2)
	return si0

def Si_1(x2):
	'''
	calculation of si1 for Lyapunov Constraints
	'''
	si1 = 2.0*(x2 - vd)/m;
	return si1

def H(x2, z):
	'''
	calculation of h for barrier function
	'''
	h = z - 1.8*x2 - x0 -(0.5*((v0-x2)**2))/(cd*g)
	return h


def B(x2, z):
	'''
	calculation of barrier function
	'''
	h = H(x2, z)
	b = -math.log(h/(1.0+h))
	return b


def LFB (x2, z):
	'''
	calculation of LFB for CBF Constraints
	'''
	Fr = FR(x2)
	h = H(x2, z)
	Lfb = -(-Fr*(v0-x2)/(cd*g*m) + 1.8*Fr/m + v0 - x2)/(h*(1.0+h))
	return Lfb


def LGB(x2, z):
	'''
	calculation of LGB for CBF Constraints
	'''
	h = H(x2, z)
	Lgb = (1.8 - (v0-x2)/(cd*g))/(m*h*(1.0+h))
	return Lgb



def PSC(x2, z):
	'''
	penality for softness in Lyapunov constraints
	'''
	b = B(x2, z)
	psc = math.exp((gamma/(10.0*b))-3)
	return psc



def Solve(x2, z, u_old):
	'''
	solve the input for safety aware ACC using CLF and CBL
	concept
	This function will take current speed(x2) and current
	distance between ego vehicle and front vehicle as 
	input and return control force as output.
	'''

	try:
		b = B(x2, z)
	except:
		return u_old

	psc = PSC(x2, z)
	# psc = math.exp(-2.0)
	Fr = FR(x2)	

	Aclf = Si_1(x2)			# control Lyapunov constraint
	bclf = -Si_0(x2)

	Acbf = LGB(x2, z)		# control barrier constraint
	bcbf = -LFB(x2, z) + (gamma/b)

	'''
	formulation for CVXOPT
		min u'*Q*u + p*u
		subject to 
			G*u <= h
	'''

	Q = 2.0*matrix([[1/m**2, 0.0], [0.0, psc]])
	p = -2.0*matrix([Fr/(m**2), 0.0])
	G = matrix([[Aclf, Acbf] ,[-1.0, 0.0]])
	h = matrix([bclf, bcbf])

	solvers.options['show_progress'] = False
	sol = solvers.qp(Q, p, G, h)
	U = sol['x']

	return U[0]
