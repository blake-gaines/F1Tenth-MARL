#!/usr/bin/env python

import numpy as np
import math
import matplotlib.pyplot as plt
import cbf

'''
system constant
'''
vd = 24.0		# Desire velocity of front vehicle (m/s)
v0 = 10.0		# Front vehicle velocity (m/s)

m = 1650.0		# mass of ego vehicle (kg)
ca = 0.3		# max acceleration ca*g
cd = 0.3		# max deacceleration -cd*g
g = 9.81		# gravitational acceleration

fsilon = 5.0	# coeff to Exponential CLF
gamma = 1.0		# Coeff to exponential CBF
x0 = 0.5		# Stopping distance from front vehicle
f0 = 0.1		# Coeff for aerodynamic drag
f1 = 5.0
f2 = 0.25

class State:
    def __init__(self, v=20.0, z =100.0):
    	"""
		Vehicle state
		v - velocity
		z - distance between ego vehicle and front vehicle
		a - acceleration (input)
		u_old - old input to calculate running average for jerk
		"""
        self.v = v
        self.z = z
        self.a = 0
        self.u_old = 3*[0]

   
    def update(self, a = 0.0, dt = 0.01):
    	"""
	    updatation for state
	    """
    	self.a = a
    	self.z += dt*(v0 - self.v)
    	self.v += dt*a;
    	return self


def simulation(t, dt = 0.01):
	"""
	simulation of ACC for given time t sec with increment of dt

	initialization of state, default intial velocity = 20m/s and
	initial distance between ego and front vehicle is 100m
	"""
	state = State()	

	velocity = [state.v]	# store velocity for plot
	dist = [state.z]		# store distance for plot
	accel = [state.a]		# store acceleration(input) for plot

	for i in np.arange(0.0,t,dt):
		"""
		running average calculation 
		"""
		run_avg = state.u_old[2] + 0.3*(state.u_old[2] - state.u_old[0]) 

		"""
		input calculation based CBF and CLF
		"""
		u = CBF.Solve(state.v, state.z, run_avg)

		'''
		upper limit constraints on input
		'''
		if u < ca*g*m:				
			state = state.update (u/m)
		else:
			state = state.update (ca*g)


		state.u_old.append(u)
		state.u_old.pop(0)
		velocity.append(state.v)
		dist.append(state.z)
		accel.append(state.a)

	return velocity, dist, accel

def main():

	t = 40.0
	dt = 0.01

	velocity, dist, accel = simulation(t, dt)

	'''
	plot
	'''
	plt.figure(1)
	plt.subplot(311)
	plt.plot(velocity, label="velocity")

	plt.subplot(312)
	plt.plot(dist, label="distance")

	plt.subplot(313)
	plt.plot(accel, label="acceleration")
	plt.show()


if __name__ == '__main__':
    main()

     